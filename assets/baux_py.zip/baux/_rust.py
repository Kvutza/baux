from __future__ import annotations

import os

os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

try:
    from . import baux_rust as _ext
except ImportError as exc:  # pragma: no cover - exercised when extension unavailable
    raise ImportError(
        "Rust extension submodule `baux.baux_rust` is not available"
    ) from exc

cuda = getattr(_ext, "cuda", None)


hypervolume2d_max = _ext.hypervolume.hypervolume2d_max
normal_hash = _ext.hash.normal_hash
Key = _ext.hash.Key
standardize_y = _ext.util.standardize_y
pareto2d_max = _ext.util.pareto2d_max
sobol_indices = _ext.util.sobol_indices
sobol_sequence = _ext.util.sobol_sequence
pareto_arms = _ext.util.pareto_arms
ensure_config_file = _ext.util.ensure_config_file
verify_upstream_lock = getattr(_ext, "verify_upstream_lock", None)
ENN = _ext.model.ENN
ENNParams = _ext.model.ENNParams
Posterior = getattr(_ext.model, "Posterior", None)
Tensor = getattr(_ext.model, "Tensor", None)
Device = getattr(_ext, "Device", None) or getattr(_ext.optimizer, "Device", None)
fit_model = _ext.fit.fit_model
subsample_loglik = _ext.fit.subsample_loglik
row_loglik = _ext.fit.row_loglik
BayesOptimizer = _ext.optimizer.BayesOptimizer
Telemetry = _ext.optimizer.Telemetry
MultiTrustRegion = _ext.optimizer.MultiTrustRegion
BpannHistory = getattr(_ext.optimizer, "BpannHistory", None)
create_optimizer = _ext.optimizer.create_optimizer
enn_tr = _ext.optimizer.enn_tr
dense_apply = getattr(_ext.optimizer, "dense_apply", None)
dense_dist2 = getattr(_ext.optimizer, "dense_dist2", None)
dense_linear = getattr(_ext.optimizer, "dense_linear", None)
DenseLinear = getattr(_ext.optimizer, "DenseLinear", None)


def _stub(name: str) -> type:
    """Return a placeholder class when Apple Metal resident types are absent."""

    def _init(self: object, *args: object, **kwargs: object) -> None:
        del self, args, kwargs
        raise RuntimeError(f"baux.{name} requires Apple Metal on macOS")

    return type(name, (), {"__init__": _init, "__module__": "baux"})


def _resident(name: str) -> object:
    found = getattr(_ext.optimizer, name, None) or getattr(
        _ext.experimental, name, None
    )
    return found if found is not None else _stub(name)


Var = _resident("Var")
Span = _resident("Span")
Region = _resident("Region")
Trial = _resident("Trial")
Portfolio = _resident("Portfolio")
RegionTrial = _resident("RegionTrial")
weight_select_ucb = getattr(_ext.optimizer, "weight_select_ucb", None)
ModelPackage = getattr(_ext.experimental, "ModelPackage", None)
NativeKdaModel = getattr(_ext.experimental, "NativeKdaModel", None)
FlameEvaluator = getattr(_ext.experimental, "FlameEvaluator", None)
MetalFlameEvaluator = getattr(_ext.experimental, "MetalFlameEvaluator", None)
MetalQwenEvaluator = getattr(_ext.experimental, "MetalQwenEvaluator", None)
ResidentBoSession = getattr(_ext.experimental, "ResidentBoSession", None)


__all__ = [
    "ENN",
    "BayesOptimizer",
    "BpannHistory",
    "DenseLinear",
    "Device",
    "ENNParams",
    "FlameEvaluator",
    "Key",
    "MetalFlameEvaluator",
    "MetalQwenEvaluator",
    "ModelPackage",
    "MultiTrustRegion",
    "NativeKdaModel",
    "Portfolio",
    "Posterior",
    "Region",
    "RegionTrial",
    "ResidentBoSession",
    "Span",
    "Telemetry",
    "Tensor",
    "Trial",
    "Var",
    "create_optimizer",
    "dense_apply",
    "dense_dist2",
    "dense_linear",
    "enn_tr",
    "ensure_config_file",
    "fit_model",
    "hypervolume2d_max",
    "normal_hash",
    "pareto2d_max",
    "pareto_arms",
    "row_loglik",
    "sobol_indices",
    "sobol_sequence",
    "standardize_y",
    "subsample_loglik",
    "verify_upstream_lock",
    "weight_select_ucb",
]
