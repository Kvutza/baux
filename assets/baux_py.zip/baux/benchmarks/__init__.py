"""Benchmark objective functions for Bayesian optimization evaluation."""

from . import synthetic
from .ackley import Ackley, DoubleAckley
from .separable_unimodal import separable_objective

__all__ = ["Ackley", "DoubleAckley", "separable_objective", "synthetic"]
