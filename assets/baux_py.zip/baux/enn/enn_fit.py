"""Hyperparameter fitting and log-likelihood scoring for ENN models."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import numpy as np

from baux._rust import row_loglik as rust_rows
from baux._rust import subsample_loglik as _rust_subsample_loglik

if TYPE_CHECKING:
    from numpy.random import Generator

    from .enn_class import ENN
    from .enn_fitter import ENNFitter
    from .enn_params import ENNParams


def subsample_loglik(
    model: ENN,
    x: np.ndarray,
    y: np.ndarray,
    *,
    paramss: list[ENNParams],
    P: int = 10,
    rng: Generator,
    y_std: np.ndarray | None = None,
) -> list[float]:
    """Score complete training arrays in model row order; use row_loglik for subsets."""
    from .enn_class import ENN as PyENN

    x_array = np.asarray(x, dtype=float)
    y_array = np.asarray(y, dtype=float)
    if y_array.ndim == 1:
        y_array = y_array.reshape(-1, 1)

    if not isinstance(model, PyENN):
        raise TypeError(f"Expected ENN, got {type(model)}")

    seed = int(rng.integers(0, 2**63 - 1))

    k_values = [p.k_neighbors for p in paramss]
    epi_scales = [p.epistemic_scale for p in paramss]
    ale_scales = [p.aleatoric_scale for p in paramss]

    y_std_arr = None
    if y_std is not None:
        y_std_arr = np.asarray(y_std, dtype=float).ravel()

    return _rust_subsample_loglik(
        model.rust_backend,
        x_array,
        y_array,
        k_values,
        epi_scales,
        ale_scales,
        P,
        seed,
        y_std_arr,
    )


def row_loglik(
    model: ENN,
    rows: list[int],
    *,
    paramss: list[ENNParams],
    P: int = 10,
    rng: Generator,
    y_std: np.ndarray | None = None,
) -> list[float]:
    """Score held-out model row IDs without ambiguous coordinate matching."""
    return rust_rows(
        model.rust_backend,
        rows,
        [p.k_neighbors for p in paramss],
        [p.epistemic_scale for p in paramss],
        [p.aleatoric_scale for p in paramss],
        P,
        int(rng.integers(0, 2**63 - 1)),
        None if y_std is None else np.asarray(y_std, dtype=float).ravel(),
    )


@dataclass(frozen=True)
class ENNIncrementalDelta:
    """Rows just appended via ``model.add`` plus the fitter tracking y_std."""

    fitter: ENNFitter
    x: np.ndarray
    y: np.ndarray
    yvar: np.ndarray | None = None


def enn_fit(
    model: ENN,
    *,
    k: int,
    num_candidates: int,
    num_samples: int = 10,
    rng: Generator,
    params_warm_start: ENNParams | None = None,
    incremental: ENNIncrementalDelta | None = None,
) -> ENNParams:
    """Fit ENN hyperparameters via ENNFitter tell/ask.

    Batch mode (``incremental`` is None): tell the full model and ask once.

    Incremental mode: tell only the delta rows that were just appended via
    ``model.add``, then ask — same rhythm as ``ENNFitter.ask``.
    """
    from .enn_class import ENN as PyENN
    from .enn_fitter import ENNFitter

    if not isinstance(model, PyENN):
        raise TypeError(f"Expected ENN, got {type(model)}")

    if incremental is None:
        fitter = ENNFitter(k=k, rng=rng)
        x_all, y_all, yvar_all = model.train_rows(list(range(len(model))))
        fitter.tell(x_all, y_all, yvar_all)
    else:
        fitter = incremental.fitter
        fitter.tell(incremental.x, incremental.y, incremental.yvar)

    return fitter.ask(
        model,
        num_candidates=num_candidates,
        num_samples=num_samples,
        params_warm_start=params_warm_start,
    )
