"""Stateful tell/ask hyperparameter fitter for ENN models."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from baux._rust import ENNFitter as _RustENNFitter
from baux._rust import ENNParams as RustENNParams

if TYPE_CHECKING:
    from numpy.random import Generator

    from .enn_class import ENN
    from .enn_params import ENNParams


class ENNFitter:
    """Incremental hyperparameter fitter tracking observation target scale."""

    def __init__(
        self,
        k: int,
        rng: Generator,
        *,
        infer_aleatoric_variance_scale: bool = True,
    ) -> None:
        seed = int(rng.integers(0, 2**63 - 1))
        self._rust = _RustENNFitter(
            k,
            seed,
            infer_aleatoric_variance_scale,
        )

    def tell(
        self,
        x: np.ndarray,
        y: np.ndarray,
        yvar: np.ndarray | None = None,
    ) -> None:
        """Register a batch for incremental y_std; must match rows added to the model."""
        x_array = np.asarray(x, dtype=float)
        y_array = np.asarray(y, dtype=float)
        if y_array.ndim == 1:
            y_array = y_array.reshape(-1, 1)
        x_array.flags.writeable = False
        y_array.flags.writeable = False
        yvar_array = None
        if yvar is not None:
            yvar_array = np.asarray(yvar, dtype=float)
            if yvar_array.ndim == 1:
                yvar_array = yvar_array.reshape(-1, 1)
            yvar_array.flags.writeable = False
        self._rust.tell(x_array, y_array, yvar_array)

    def y_std(self) -> np.ndarray:
        """Return empirical standard deviation of observed targets per output."""
        return np.asarray(self._rust.y_std(), dtype=float)

    def ask(
        self,
        model: ENN,
        *,
        num_candidates: int,
        num_samples: int,
        params_warm_start: ENNParams | None = None,
    ) -> ENNParams:
        """Fit hyperparameters; tell row count must equal model.num_obs() or y_std is wrong."""
        from .enn_class import ENN as PyENN
        from .enn_params import ENNParams as PyENNParams

        if not isinstance(model, PyENN):
            raise TypeError(f"Expected ENN, got {type(model)}")

        rust_warm_start = None
        if params_warm_start is not None:
            rust_warm_start = RustENNParams(
                params_warm_start.k_neighbors,
                params_warm_start.epistemic_scale,
                params_warm_start.aleatoric_scale,
            )

        rust_result = self._rust.ask(
            model.rust_backend,
            num_candidates,
            num_samples,
            rust_warm_start,
        )

        return PyENNParams(
            k_neighbors=rust_result.k_neighbors,
            epistemic_scale=rust_result.epistemic_scale,
            aleatoric_scale=rust_result.aleatoric_scale,
        )
