"""Weighted neighbor statistics for ENN posterior evaluation."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import numpy as np


@dataclass(frozen=True)
class WeightedStats:
    """Normalized neighbor weights and predictive moments for ENN queries."""

    w_normalized: np.ndarray
    l2: np.ndarray
    mu: np.ndarray
    se: np.ndarray
    se_epi: np.ndarray
    se_ale: np.ndarray
