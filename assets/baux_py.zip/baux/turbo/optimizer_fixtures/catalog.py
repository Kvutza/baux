"""Catalog of golden optimizer fixture configurations and objective functions."""

from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import dataclass

import numpy as np
from baux.benchmarks.separable_unimodal import separable_objective
from baux.turbo.config import (
    AcquisitionKind,
    CandidateConfig,
    ENNSurrogate,
    MorboTrustRegion,
    MultiObjectiveConfig,
    OptimizerConfig,
    SurrogateFit,
    TurboTrustRegion,
    lhd_only,
    turbo_enn,
    turbo_zero,
)

UNIT_BOX_BOUNDS = np.array([[0.0, 1.0], [0.0, 1.0]], dtype=float)
MORBO_SEPARABLE_BOUNDS = np.array([[-300.0, 600.0], [0.2, 1.0]], dtype=float)


def sphere_objective(x: np.ndarray) -> np.ndarray:
    """Evaluate negative squared Euclidean distance from `[0.5, ..., 0.5]`."""
    return (-np.sum((x - 0.5) ** 2, axis=1)).reshape(-1, 1)


FIXTURE_OBJECTIVES: dict[str, Callable[[np.ndarray], np.ndarray]] = {
    "sphere_centered_0.5": sphere_objective,
    "separable_unimodal_two_metric": separable_objective,
}


@dataclass(frozen=True)
class FixtureRunSpec:
    """Execution parameters for a fixture run."""

    num_cycles: int
    num_arms: int
    objective: str


@dataclass(frozen=True)
class FixtureGeneratorEntry:
    """Specification for generating a family of golden optimizer fixtures."""

    prefix: str
    config_key: str
    bounds: np.ndarray
    run: FixtureRunSpec
    morbo: bool = False


PREFIX_CONFIG: dict[str, OptimizerConfig] = {
    "turbo_enn_ucb_single": turbo_enn(
        acquisition=AcquisitionKind.UCB,
        enn=ENNSurrogate(k=4, fit=SurrogateFit(num_samples=10)),
        num_init=3,
    ),
    "turbo_enn_thompson_single": turbo_enn(
        acquisition=AcquisitionKind.THOMPSON,
        enn=ENNSurrogate(k=4, fit=SurrogateFit(num_samples=10)),
        num_init=3,
    ),
    "turbo_enn_pareto_multi": turbo_enn(
        acquisition=AcquisitionKind.PARETO,
        enn=ENNSurrogate(k=3, fit=SurrogateFit(num_samples=10)),
        num_init=2,
    ),
    "turbo_zero": turbo_zero(num_init=3),
    "turbo_enn_noise_aware": turbo_enn(
        acquisition=AcquisitionKind.UCB,
        enn=ENNSurrogate(k=3, fit=SurrogateFit(num_samples=8)),
        trust_region=TurboTrustRegion(noise_aware=True),
        num_init=2,
    ),
    "lhd_only": lhd_only(num_init=3),
    "morbo_enn_separable_unimodal": turbo_enn(
        acquisition=AcquisitionKind.THOMPSON,
        enn=ENNSurrogate(
            k=4,
            fit=SurrogateFit(num_samples=4, num_candidates=8),
        ),
        trust_region=MorboTrustRegion(
            multi_objective=MultiObjectiveConfig(num_metrics=2),
            noise_aware=True,
        ),
        num_init=8,
        candidates=CandidateConfig(num_candidates=64),
    ),
}


FIXTURE_GENERATOR_ENTRIES: tuple[FixtureGeneratorEntry, ...] = (
    FixtureGeneratorEntry(
        "teucboneseed",
        "turbo_enn_ucb_single",
        UNIT_BOX_BOUNDS,
        FixtureRunSpec(4, 3, "sphere_centered_0.5"),
    ),
    FixtureGeneratorEntry(
        "tethomoneseed",
        "turbo_enn_thompson_single",
        UNIT_BOX_BOUNDS,
        FixtureRunSpec(4, 3, "sphere_centered_0.5"),
    ),
    FixtureGeneratorEntry(
        "teparmseed",
        "turbo_enn_pareto_multi",
        UNIT_BOX_BOUNDS,
        FixtureRunSpec(4, 2, "sphere_centered_0.5"),
    ),
    FixtureGeneratorEntry(
        "tzeroseed",
        "turbo_zero",
        UNIT_BOX_BOUNDS,
        FixtureRunSpec(4, 3, "sphere_centered_0.5"),
    ),
    FixtureGeneratorEntry(
        "tenzawrseed",
        "turbo_enn_noise_aware",
        UNIT_BOX_BOUNDS,
        FixtureRunSpec(4, 2, "sphere_centered_0.5"),
    ),
    FixtureGeneratorEntry(
        "lhdonseed",
        "lhd_only",
        UNIT_BOX_BOUNDS,
        FixtureRunSpec(4, 3, "sphere_centered_0.5"),
    ),
    FixtureGeneratorEntry(
        "mbesepuniseed",
        "morbo_enn_separable_unimodal",
        MORBO_SEPARABLE_BOUNDS,
        FixtureRunSpec(8, 4, "separable_unimodal_two_metric"),
        morbo=True,
    ),
)


def name_prefix(name: str) -> str:
    """Strip trailing seed digits from a fixture name to obtain its prefix."""
    m = re.fullmatch(r"(.+seed)[0-9]+", name)
    return m.group(1) if m else name


def entry_name(name: str) -> FixtureGeneratorEntry:
    """Look up the catalog generator entry matching a fixture name."""
    key = name_prefix(name)
    for entry in FIXTURE_GENERATOR_ENTRIES:
        if entry.prefix == key:
            return entry
    raise ValueError(f"unknown fixture name {name!r}")


def subdir_entry(entry: FixtureGeneratorEntry) -> str:
    """Return the fixture subdirectory name (`morbo` or `optimizer`) for an entry."""
    return "morbo" if entry.morbo else "optimizer"


def catalog_names() -> tuple[str, ...]:
    """Return all expected fixture names across catalog entries and seeds."""
    return tuple(
        f"{entry.prefix}{seed}"
        for entry in FIXTURE_GENERATOR_ENTRIES
        for seed in (0, 1, 2)
    )


EXPECTED_OPTIMIZER_FIXTURE_NAMES = catalog_names()
