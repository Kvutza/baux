"""Golden trajectory loading, invariant checking, and replay verification."""

from __future__ import annotations

import tomllib
from pathlib import Path
from typing import Any

import numpy as np
from baux.turbo.config import OptimizerConfig

from .capture import RNG_SEMANTICS, UPSTREAM_ENN_REVISION
from .catalog import (
    FIXTURE_OBJECTIVES,
    PREFIX_CONFIG,
    entry_name,
    subdir_entry,
)

_PACKAGE_FIXTURES_ROOT = Path(__file__).resolve().parent / "data"
_SOURCE_FIXTURES_ROOT = Path(__file__).resolve().parents[4] / "tests" / "fixtures"
FIXTURES_ROOT = (
    _PACKAGE_FIXTURES_ROOT if _PACKAGE_FIXTURES_ROOT.is_dir() else _SOURCE_FIXTURES_ROOT
)

EXACT_RTOL = 1e-14
EXACT_ATOL = 1e-14
TR_RTOL = 1e-9
TR_ATOL = 1e-9


def _config(name: str) -> OptimizerConfig:
    return PREFIX_CONFIG[entry_name(name).config_key]


def _dirname(name: str) -> Path:
    entry = entry_name(name)
    return FIXTURES_ROOT / subdir_entry(entry)


def load_fixture(name: str) -> dict[str, Any]:
    """Load a golden optimizer trajectory fixture from its TOML file."""
    path = _dirname(name) / f"{name}.toml"
    if not path.is_file():
        raise FileNotFoundError(f"missing optimizer replay fixture: {path}")
    return tomllib.loads(path.read_text(encoding="utf-8"))


def assert_invariants(data: dict[str, Any]) -> None:
    """Assert metadata, bounds, objective, and trust-region invariants on a fixture."""
    assert data["upstream_enn_revision"] == UPSTREAM_ENN_REVISION
    assert data["rng_semantics"] == RNG_SEMANTICS
    bounds = np.array(data["bounds"], dtype=float)
    objective_fn = FIXTURE_OBJECTIVES[str(data["objective"])]
    prev_tr_obs = 0
    for step in data["steps"]:
        x = np.array(step["ask"], dtype=float)
        y = np.array(step["tell_y"], dtype=float)
        assert x.shape[1] == bounds.shape[0]
        assert y.shape[0] == x.shape[0]
        assert np.all(np.isfinite(x))
        assert np.all(np.isfinite(y))
        assert np.all(x >= bounds[:, 0] - 1e-9)
        assert np.all(x <= bounds[:, 1] + 1e-9)
        np.testing.assert_allclose(objective_fn(x), y, rtol=EXACT_RTOL, atol=EXACT_ATOL)
        assert 0.0 < step["tr_length"] <= 2.5
        tr_obs = int(step["tr_count"])
        assert tr_obs >= prev_tr_obs
        prev_tr_obs = tr_obs


def replay_check(data: dict[str, Any], config: OptimizerConfig) -> None:
    """Replay an optimizer against a golden fixture and assert step-by-step parity."""
    from baux.state import _makeinner

    assert_invariants(data)
    bounds = np.array(data["bounds"], dtype=float)
    seed = int(data["seed"])
    rng = np.random.default_rng(seed)
    opt = _makeinner(bounds, config, int(rng.integers(2**63 - 1)))
    num_arms = int(data["num_arms"])
    for step in data["steps"]:
        x_golden = np.array(step["ask"], dtype=float)
        y_golden = np.array(step["tell_y"], dtype=float)
        if y_golden.ndim == 1:
            y_golden = y_golden.reshape(-1, 1)
        opt, x = opt.ask(num_arms)
        assert isinstance(x, np.ndarray)
        assert x.shape == (num_arms, bounds.shape[0])
        assert np.all(np.isfinite(x))
        assert np.all(x >= bounds[:, 0] - 1e-9)
        assert np.all(x <= bounds[:, 1] + 1e-9)
        np.testing.assert_allclose(x, x_golden, rtol=EXACT_RTOL, atol=EXACT_ATOL)
        y_var_golden = None
        if "tell_y_var" in step:
            y_var_golden = np.array(step["tell_y_var"], dtype=float)
            if y_var_golden.ndim == 1:
                y_var_golden = y_var_golden.reshape(-1, 1)
        elif "y_var" in step:
            y_var_golden = np.array(step["y_var"], dtype=float)
            if y_var_golden.ndim == 1:
                y_var_golden = y_var_golden.reshape(-1, 1)
        opt = opt.tell(x_golden, y_golden, y_var=y_var_golden)
        assert int(opt.num_observations()) == int(step["tr_count"])
        np.testing.assert_allclose(
            opt.tr_length(),
            float(step["tr_length"]),
            rtol=TR_RTOL,
            atol=TR_ATOL,
        )
